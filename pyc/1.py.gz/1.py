#!/usr/bin/python

print('1.py.print')

